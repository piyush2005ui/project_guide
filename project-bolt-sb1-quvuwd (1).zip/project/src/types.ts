export interface Question {
  id: number;
  text: string;
  options: string[];
}

export interface UserProfile {
  education: string;
  year: string;
  interests: string[];
  skills: string[];
  specification: string;
}

export interface AssessmentResult {
  score: number;
  recommendations: string[];
  suggestedPaths: string[];
}