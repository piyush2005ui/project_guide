import { GoogleGenerativeAI } from '@google/generative-ai';

const API_KEY = 'AIzaSyAtjX--nXW-qfumUC1BOPLsTUKfyVuCjK4';
const genAI = new GoogleGenerativeAI(API_KEY);

export async function getChatResponse(prompt: string) {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-pro"});
    
    const result = await model.generateContent(`
      You are a professional career counselor with expertise in guiding students and professionals.
      Provide detailed, actionable advice for the following career-related question:
      ${prompt}
      
      Format your response in markdown with clear sections and bullet points where appropriate.
    `);
    
    const response = result.response;
    return response.text();
  } catch (error) {
    console.error('AI API Error:', error);
    throw new Error('Failed to get AI response. Please try again.');
  }
}