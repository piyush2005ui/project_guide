import React, { useState } from 'react';
import Header from './components/Header';
import AssessmentQuestions, { questions } from './components/AssessmentQuestions';
import ChatInterface from './components/ChatInterface';
import { GraduationCap, BookOpen, BrainCircuit, ArrowRight } from 'lucide-react';
import type { UserProfile, AssessmentResult } from './types';

function App() {
  const [step, setStep] = useState<'welcome' | 'profile' | 'assessment' | 'results' | 'chat'>('welcome');
  const [userProfile, setUserProfile] = useState<UserProfile>({
    education: '',
    year: '',
    interests: [],
    skills: [],
    specification: ''
  });
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [assessmentResult, setAssessmentResult] = useState<AssessmentResult | null>(null);

  const handleProfileSubmit = (profile: UserProfile) => {
    setUserProfile(profile);
    setStep('assessment');
  };

  const handleAnswer = (answer: string) => {
    const newAnswers = [...answers, answer];
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      const result: AssessmentResult = {
        score: Math.floor(Math.random() * 100),
        recommendations: [
          "Based on your analytical skills, consider Data Science",
          "Your communication skills suggest Product Management",
          "Your technical interests align with Software Development"
        ],
        suggestedPaths: [
          "Master's in Computer Science",
          "MBA with Tech Specialization",
          "Data Science Certification"
        ]
      };
      setAssessmentResult(result);
      setStep('results');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 py-12">
        {step === 'welcome' && (
          <div className="text-center space-y-10">
            <div className="space-y-4">
              <h1 className="text-5xl font-bold text-gray-900 bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
                Discover Your Perfect Career Path
              </h1>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Let AI guide you through personalized career recommendations based on your skills and interests
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <div className="bg-white p-8 rounded-2xl shadow-xl transform hover:-translate-y-1 transition-all duration-300">
                <div className="bg-purple-100 p-3 rounded-lg w-fit mb-6">
                  <GraduationCap className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold mb-3">Education Planning</h3>
                <p className="text-gray-600">Get tailored recommendations for your academic journey</p>
              </div>

              <div className="bg-white p-8 rounded-2xl shadow-xl transform hover:-translate-y-1 transition-all duration-300">
                <div className="bg-purple-100 p-3 rounded-lg w-fit mb-6">
                  <BookOpen className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold mb-3">Skill Assessment</h3>
                <p className="text-gray-600">Discover your strengths and growth opportunities</p>
              </div>

              <div className="bg-white p-8 rounded-2xl shadow-xl transform hover:-translate-y-1 transition-all duration-300">
                <div className="bg-purple-100 p-3 rounded-lg w-fit mb-6">
                  <BrainCircuit className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold mb-3">AI Career Chat</h3>
                <p className="text-gray-600">Get instant answers to your career questions</p>
              </div>
            </div>

            <button
              onClick={() => setStep('profile')}
              className="inline-flex items-center px-8 py-4 text-lg font-semibold text-white bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
            >
              Begin Your Journey
              <ArrowRight className="ml-2 h-5 w-5" />
            </button>
          </div>
        )}

        {step === 'profile' && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white p-8 rounded-2xl shadow-xl">
              <h2 className="text-3xl font-bold mb-8 text-gray-900">Tell us about yourself</h2>
              <form onSubmit={(e) => {
                e.preventDefault();
                handleProfileSubmit(userProfile);
              }}>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Current Education Level
                    </label>
                    <select
                      value={userProfile.education}
                      onChange={(e) => setUserProfile({...userProfile, education: e.target.value})}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      required
                    >
                      <option value="">Select education level</option>
                      <option value="undergraduate">Undergraduate</option>
                      <option value="masters">Masters</option>
                      <option value="phd">PhD</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Current Year
                    </label>
                    <select
                      value={userProfile.year}
                      onChange={(e) => setUserProfile({...userProfile, year: e.target.value})}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      required
                    >
                      <option value="">Select year</option>
                      <option value="1">First Year</option>
                      <option value="2">Second Year</option>
                      <option value="3">Third Year</option>
                      <option value="4">Fourth Year</option>
                      <option value="5">Fifth Year</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Specification/Field of Interest
                    </label>
                    <input
                      type="text"
                      value={userProfile.specification}
                      onChange={(e) => setUserProfile({...userProfile, specification: e.target.value})}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="e.g., Computer Science, Business, Engineering"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 px-6 text-white bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200 font-semibold"
                  >
                    Continue to Assessment
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {step === 'assessment' && (
          <AssessmentQuestions
            currentQuestion={currentQuestion}
            onAnswer={handleAnswer}
          />
        )}

        {step === 'results' && assessmentResult && (
          <div className="max-w-4xl mx-auto">
            <div className="bg-white p-8 rounded-2xl shadow-xl">
              <h2 className="text-3xl font-bold mb-8 text-gray-900">Your Career Assessment Results</h2>
              
              <div className="mb-8">
                <div className="relative h-4 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="absolute top-0 left-0 h-full bg-gradient-to-r from-purple-600 to-indigo-600 transition-all duration-1000"
                    style={{ width: `${assessmentResult.score}%` }}
                  ></div>
                </div>
                <p className="text-center mt-3 font-semibold">
                  Compatibility Score: {assessmentResult.score}%
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="bg-purple-50 p-6 rounded-xl">
                  <h3 className="text-xl font-bold mb-4 text-purple-900">Recommendations</h3>
                  <ul className="space-y-3">
                    {assessmentResult.recommendations.map((rec, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <span className="text-purple-600 font-bold">•</span>
                        <span className="text-gray-700">{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-indigo-50 p-6 rounded-xl">
                  <h3 className="text-xl font-bold mb-4 text-indigo-900">Suggested Paths</h3>
                  <ul className="space-y-3">
                    {assessmentResult.suggestedPaths.map((path, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <span className="text-indigo-600 font-bold">•</span>
                        <span className="text-gray-700">{path}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <button
                onClick={() => setStep('chat')}
                className="mt-8 w-full py-4 text-white bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200 font-semibold"
              >
                Chat with AI Career Advisor
              </button>
            </div>
          </div>
        )}

        {step === 'chat' && (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-6 text-gray-900">AI Career Advisor</h2>
            <ChatInterface />
          </div>
        )}
      </main>
    </div>
  );
}

export default App;