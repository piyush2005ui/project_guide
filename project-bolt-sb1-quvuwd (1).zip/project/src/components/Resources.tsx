import React from 'react';
import { Book, Video, Certificate, Users } from 'lucide-react';

const resources = {
  courses: [
    {
      title: "Complete Web Development Bootcamp",
      platform: "Udemy",
      duration: "63 hours",
      rating: 4.8,
      link: "#"
    },
    {
      title: "Data Science Specialization",
      platform: "Coursera",
      duration: "8 months",
      rating: 4.7,
      link: "#"
    },
    {
      title: "Machine Learning A-Z",
      platform: "Udemy",
      duration: "44 hours",
      rating: 4.9,
      link: "#"
    }
  ],
  certifications: [
    {
      title: "AWS Certified Solutions Architect",
      provider: "Amazon",
      duration: "6 months",
      cost: "$150",
      link: "#"
    },
    {
      title: "Google Cloud Professional",
      provider: "Google",
      duration: "3 months",
      cost: "$200",
      link: "#"
    },
    {
      title: "Microsoft Azure Fundamentals",
      provider: "Microsoft",
      duration: "2 months",
      cost: "$99",
      link: "#"
    }
  ],
  communities: [
    {
      name: "Developer Community Hub",
      members: "50K+",
      focus: "Web Development",
      platform: "Discord",
      link: "#"
    },
    {
      name: "Data Science Network",
      members: "35K+",
      focus: "Data Science & ML",
      platform: "Slack",
      link: "#"
    },
    {
      name: "Tech Career Growth",
      members: "25K+",
      focus: "Career Development",
      platform: "LinkedIn",
      link: "#"
    }
  ]
};

export default function Resources() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold text-gray-900 mb-4">Learning Resources</h2>
        <p className="text-xl text-gray-600">Curated resources to help you achieve your career goals</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="bg-white p-8 rounded-2xl shadow-xl">
          <div className="flex items-center space-x-3 mb-6">
            <div className="bg-purple-100 p-3 rounded-lg">
              <Video className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900">Online Courses</h3>
          </div>

          <div className="space-y-4">
            {resources.courses.map((course, index) => (
              <div key={index} className="border-b border-gray-100 pb-4">
                <h4 className="font-semibold text-gray-900">{course.title}</h4>
                <div className="text-sm text-gray-600">
                  <p>Platform: {course.platform}</p>
                  <p>Duration: {course.duration}</p>
                  <p>Rating: ⭐ {course.rating}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-8 rounded-2xl shadow-xl">
          <div className="flex items-center space-x-3 mb-6">
            <div className="bg-purple-100 p-3 rounded-lg">
              <Certificate className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900">Certifications</h3>
          </div>

          <div className="space-y-4">
            {resources.certifications.map((cert, index) => (
              <div key={index} className="border-b border-gray-100 pb-4">
                <h4 className="font-semibold text-gray-900">{cert.title}</h4>
                <div className="text-sm text-gray-600">
                  <p>Provider: {cert.provider}</p>
                  <p>Duration: {cert.duration}</p>
                  <p>Cost: {cert.cost}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-8 rounded-2xl shadow-xl">
          <div className="flex items-center space-x-3 mb-6">
            <div className="bg-purple-100 p-3 rounded-lg">
              <Users className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900">Communities</h3>
          </div>

          <div className="space-y-4">
            {resources.communities.map((community, index) => (
              <div key={index} className="border-b border-gray-100 pb-4">
                <h4 className="font-semibold text-gray-900">{community.name}</h4>
                <div className="text-sm text-gray-600">
                  <p>Members: {community.members}</p>
                  <p>Focus: {community.focus}</p>
                  <p>Platform: {community.platform}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-12 text-center">
        <p className="text-gray-600 mb-4">Need personalized resource recommendations?</p>
        <button className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-8 py-3 rounded-lg font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200">
          Get Custom Learning Path
        </button>
      </div>
    </div>
  );
}