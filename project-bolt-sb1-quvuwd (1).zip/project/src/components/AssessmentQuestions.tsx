import React from 'react';
import type { Question } from '../types';

export const questions: Question[] = [
  {
    id: 1,
    text: "How do you prefer to solve problems?",
    options: ["Analytically", "Creatively", "Collaboratively", "Systematically"]
  },
  {
    id: 2,
    text: "Which work environment appeals to you most?",
    options: ["Fast-paced startup", "Established corporation", "Academic institution", "Remote/flexible work"]
  },
  {
    id: 3,
    text: "What type of tasks energize you?",
    options: ["Data analysis", "Creative design", "Team coordination", "Technical problem-solving"]
  },
  {
    id: 4,
    text: "How do you prefer to learn new skills?",
    options: ["Structured courses", "Hands-on practice", "Peer learning", "Self-guided research"]
  },
  {
    id: 5,
    text: "What's your preferred leadership style?",
    options: ["Democratic", "Authoritative", "Coaching", "Delegative"]
  },
  {
    id: 6,
    text: "Which technology sector interests you most?",
    options: ["AI/Machine Learning", "Web Development", "Cybersecurity", "Cloud Computing"]
  },
  {
    id: 7,
    text: "How do you handle deadlines?",
    options: ["Plan well in advance", "Work best under pressure", "Delegate and coordinate", "Flexible adaptation"]
  },
  {
    id: 8,
    text: "What's your ideal team size?",
    options: ["Small (2-5 people)", "Medium (5-15 people)", "Large (15+ people)", "Prefer working independently"]
  },
  {
    id: 9,
    text: "Which skill would you most like to develop?",
    options: ["Technical expertise", "Leadership abilities", "Communication skills", "Project management"]
  },
  {
    id: 10,
    text: "What motivates you most at work?",
    options: ["Innovation opportunities", "Career growth", "Work-life balance", "Financial rewards"]
  },
  {
    id: 11,
    text: "How do you prefer to communicate?",
    options: ["Written documentation", "Face-to-face meetings", "Visual presentations", "Quick digital messages"]
  },
  {
    id: 12,
    text: "What's your approach to risk-taking?",
    options: ["Calculated risks", "Conservative decisions", "Bold innovations", "Data-driven choices"]
  },
  {
    id: 13,
    text: "Which industry excites you most?",
    options: ["Technology", "Healthcare", "Finance", "Education"]
  },
  {
    id: 14,
    text: "How do you measure success?",
    options: ["Personal growth", "Project completion", "Team achievements", "Innovation impact"]
  },
  {
    id: 15,
    text: "What's your preferred work schedule?",
    options: ["Traditional 9-5", "Flexible hours", "Project-based sprints", "Rotating shifts"]
  }
];

interface Props {
  currentQuestion: number;
  onAnswer: (answer: string) => void;
}

export default function AssessmentQuestions({ currentQuestion, onAnswer }: Props) {
  const question = questions[currentQuestion];

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white p-8 rounded-2xl shadow-xl">
        <div className="mb-8">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-gradient-to-r from-purple-600 to-indigo-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
            ></div>
          </div>
          <p className="text-right mt-2 text-sm text-gray-600">
            Question {currentQuestion + 1} of {questions.length}
          </p>
        </div>

        <h3 className="text-2xl font-bold mb-6 text-gray-900">{question.text}</h3>
        
        <div className="space-y-4">
          {question.options.map((option, index) => (
            <button
              key={index}
              onClick={() => onAnswer(option)}
              className="w-full p-4 text-left rounded-xl border-2 border-gray-200 hover:border-purple-500 hover:bg-purple-50 transition-all duration-200 group"
            >
              <span className="text-gray-700 group-hover:text-purple-700 font-medium">
                {option}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}