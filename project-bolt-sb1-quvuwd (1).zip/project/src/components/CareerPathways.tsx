import React from 'react';
import { BookOpen, Code, Database, Brain, Briefcase } from 'lucide-react';

const pathways = [
  {
    title: "Software Development",
    icon: Code,
    description: "Build the future of technology through programming",
    roles: ["Frontend Developer", "Backend Engineer", "Full-Stack Developer", "Mobile App Developer"],
    skills: ["JavaScript", "Python", "React", "Node.js", "Cloud Services"],
    certifications: ["AWS Certified Developer", "Google Cloud Professional", "Microsoft Certified: Azure"]
  },
  {
    title: "Data Science",
    icon: Database,
    description: "Transform data into actionable insights",
    roles: ["Data Scientist", "Data Analyst", "Machine Learning Engineer", "Business Intelligence Analyst"],
    skills: ["Python", "R", "SQL", "Machine Learning", "Statistical Analysis"],
    certifications: ["IBM Data Science Professional", "Google Data Analytics", "Microsoft Data Scientist"]
  },
  {
    title: "AI/ML Engineering",
    icon: Brain,
    description: "Pioneer the future of artificial intelligence",
    roles: ["ML Engineer", "AI Researcher", "NLP Engineer", "Computer Vision Engineer"],
    skills: ["Python", "TensorFlow", "PyTorch", "Deep Learning", "Mathematics"],
    certifications: ["TensorFlow Developer", "AWS Machine Learning", "Deep Learning Specialization"]
  },
  {
    title: "Product Management",
    icon: Briefcase,
    description: "Lead product strategy and development",
    roles: ["Product Manager", "Product Owner", "Technical Product Manager", "Growth PM"],
    skills: ["Agile", "User Research", "Strategy", "Analytics", "Leadership"],
    certifications: ["Certified Product Manager", "Agile Certified Practitioner", "Scrum Product Owner"]
  }
];

export default function CareerPathways() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold text-gray-900 mb-4">Career Pathways</h2>
        <p className="text-xl text-gray-600">Explore detailed career paths tailored to your interests and skills</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {pathways.map((pathway, index) => (
          <div key={index} className="bg-white p-8 rounded-2xl shadow-xl">
            <div className="flex items-center space-x-4 mb-6">
              <div className="bg-purple-100 p-3 rounded-lg">
                <pathway.icon className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">{pathway.title}</h3>
            </div>
            
            <p className="text-gray-600 mb-6">{pathway.description}</p>

            <div className="space-y-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Key Roles</h4>
                <div className="flex flex-wrap gap-2">
                  {pathway.roles.map((role, idx) => (
                    <span key={idx} className="px-3 py-1 bg-purple-50 text-purple-700 rounded-full text-sm">
                      {role}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Essential Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {pathway.skills.map((skill, idx) => (
                    <span key={idx} className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-sm">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Recommended Certifications</h4>
                <ul className="list-disc list-inside text-gray-600 space-y-1">
                  {pathway.certifications.map((cert, idx) => (
                    <li key={idx}>{cert}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl p-8 text-white">
        <h3 className="text-2xl font-bold mb-4">Need More Guidance?</h3>
        <p className="mb-6">Our AI career advisor can help you explore these pathways in detail and create a personalized development plan.</p>
        <button className="bg-white text-purple-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
          Chat with AI Advisor
        </button>
      </div>
    </div>
  );
}