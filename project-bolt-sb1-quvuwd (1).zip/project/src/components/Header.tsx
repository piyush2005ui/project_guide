import React from 'react';
import { Compass } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-2 rounded-lg">
              <Compass className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
              CareerGuide AI
            </h1>
          </div>
          <nav className="hidden md:flex items-center space-x-8">
            <a href="/profile" className="text-gray-600 hover:text-purple-600 transition-colors duration-200">
              Your Profile
            </a>
            <a href="/assessment" className="text-gray-600 hover:text-purple-600 transition-colors duration-200">
              Assessment
            </a>
            <a href="/pathways" className="text-gray-600 hover:text-purple-600 transition-colors duration-200">
              Career Pathways
            </a>
            <a href="/resources" className="text-gray-600 hover:text-purple-600 transition-colors duration-200">
              Resources
            </a>
            <a href="/chat" className="text-gray-600 hover:text-purple-600 transition-colors duration-200">
              AI Chat
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
}